const generateConfig = require('./generateConfig')
generateConfig()
